import express from "express";
import { createProxyMiddleware } from "http-proxy-middleware";
import fs from "fs";
import path from "path";

const app = express();
const PORT = process.env.PORT || 8091;
const CTRL = process.env.CTRL || "http://192.168.2.80:3000";
// Environment source: "local" (default) reads public/data/env.json
// or "azure" pulls from an Azure Functions endpoint that returns latest readings
const AZURE_LATEST_URL = process.env.AZURE_LATEST_URL || "";
const ENV_SOURCE = process.env.ENV_SOURCE || (AZURE_LATEST_URL ? "azure" : "local");
const ENV_PATH = path.resolve("./public/data/env.json");
const DATA_DIR = path.resolve("./public/data");

app.use(express.json({ limit: "1mb" }));

// Health (includes quick controller reachability check)
app.get("/healthz", async (req, res) => {
  const started = Date.now();
  let controllerReachable = false;
  let controllerStatus = null;
  try {
    const ac = new AbortController();
    const t = setTimeout(() => ac.abort(), 1200);
    try {
      const r = await fetch(CTRL, { method: 'HEAD', signal: ac.signal });
      controllerReachable = r.ok;
      controllerStatus = r.status;
    } catch (e) {
      controllerReachable = false;
      controllerStatus = e.name === 'AbortError' ? 'timeout' : (e.message || 'error');
    } finally {
      clearTimeout(t);
    }
  } catch (_) {}
  res.json({ ok: true, controller: CTRL, controllerReachable, controllerStatus, envSource: ENV_SOURCE, azureLatestUrl: AZURE_LATEST_URL || null, ts: new Date(), dtMs: Date.now() - started });
});

// Proxy API
app.use("/api", createProxyMiddleware({
  target: CTRL,
  changeOrigin: true,
  pathRewrite: { "^/api": "" }
}));

// Static files
app.use(express.static("./public"));

// Config endpoint to surface runtime flags
app.get('/config', (req, res) => {
  res.json({ singleServer: true, controller: CTRL, envSource: ENV_SOURCE, azureLatestUrl: AZURE_LATEST_URL || null });
});

// --- Environment Telemetry Endpoints (Azure-ready) ---
// Utility: compute VPD (kPa) from tempC and RH%
function computeVPDkPa(tempC, rhPercent) {
  if (typeof tempC !== 'number' || typeof rhPercent !== 'number' || Number.isNaN(tempC) || Number.isNaN(rhPercent)) return null;
  const svp = 0.6108 * Math.exp((17.27 * tempC) / (tempC + 237.3)); // kPa
  const rh = Math.min(Math.max(rhPercent / 100, 0), 1);
  const vpd = svp * (1 - rh);
  return Math.round(vpd * 100) / 100; // 2 decimals
}

// In-memory history cache for Azure mode: key => [values]
const azureHist = new Map();
const pushHist = (key, val, max = 100) => {
  if (val == null || Number.isNaN(val)) return;
  const arr = azureHist.get(key) || [];
  arr.unshift(val);
  if (arr.length > max) arr.length = max;
  azureHist.set(key, arr);
};

// GET: return current environment zones
app.get("/env", async (req, res) => {
  if (ENV_SOURCE === 'azure' && AZURE_LATEST_URL) {
    try {
      const params = new URLSearchParams();
      if (req.query.zone) params.set('zone', req.query.zone);
      if (req.query.deviceId) params.set('deviceId', req.query.deviceId);
      const url = params.toString() ? `${AZURE_LATEST_URL}?${params.toString()}` : AZURE_LATEST_URL;
      const r = await fetch(url, { method: 'GET', headers: { 'accept': 'application/json' } });
      if (!r.ok) throw new Error(`Azure endpoint ${r.status}`);
      const list = await r.json(); // [{ zone, deviceId, temperature, humidity, co2, battery, rssi, timestamp }]

      const zonesMap = new Map();
      for (const e of Array.isArray(list) ? list : []) {
        const zoneId = e.zone || 'DefaultZone';
        const z = zonesMap.get(zoneId) || { id: zoneId, name: zoneId, location: zoneId, sensors: {}, meta: {} };
        const t = Number(e.temperature);
        const h = Number(e.humidity);
        const c = Number(e.co2);
        const vpd = computeVPDkPa(t, h);

        // meta
        if (typeof e.battery === 'number') z.meta.battery = e.battery;
        if (typeof e.rssi === 'number') z.meta.rssi = e.rssi;
        if (e.timestamp) z.meta.lastUpdated = e.timestamp;

        // sensors
        const ensure = (k, val) => {
          z.sensors[k] = z.sensors[k] || { current: null, setpoint: { min: null, max: null }, history: [] };
          if (typeof val === 'number' && !Number.isNaN(val)) {
            z.sensors[k].current = val;
            // update history cache
            const histKey = `${zoneId}:${k}`;
            pushHist(histKey, val);
            z.sensors[k].history = azureHist.get(histKey) || [];
          }
        };
        ensure('tempC', t);
        ensure('rh', h);
        ensure('co2', c);
        if (vpd != null) ensure('vpd', vpd);

        zonesMap.set(zoneId, z);
      }

      const payload = { zones: Array.from(zonesMap.values()) };
      res.setHeader('Content-Type', 'application/json');
      return res.status(200).json(payload);
    } catch (e) {
      // Fallback to last known cache if available
      if (azureHist.size > 0) {
        const byZone = {};
        for (const [key, arr] of azureHist.entries()) {
          const [zoneId, metric] = key.split(':');
          byZone[zoneId] = byZone[zoneId] || { id: zoneId, name: zoneId, location: zoneId, sensors: {} };
          byZone[zoneId].sensors[metric] = { current: arr[0] ?? null, setpoint: { min: null, max: null }, history: arr };
        }
        const payload = { zones: Object.values(byZone) };
        res.setHeader('Content-Type', 'application/json');
        return res.status(200).json(payload);
      }
      return res.status(502).json({ ok: false, error: `Azure fetch failed: ${e.message}` });
    }
  }

  // Local file mode (default)
  try {
    const raw = fs.readFileSync(ENV_PATH, "utf8");
    res.setHeader("Content-Type", "application/json");
    return res.status(200).send(raw);
  } catch (e) {
    return res.status(500).json({ ok: false, error: e.message });
  }
});

// POST: ingest a telemetry message and upsert into env.json
// Expected body: { zoneId, name, temperature, humidity, vpd, co2, battery, rssi, source }
app.post("/ingest/env", (req, res) => {
  try {
    const { zoneId, name, temperature, humidity, vpd, co2, battery, rssi, source } = req.body || {};
    if (!zoneId) return res.status(400).json({ ok: false, error: "zoneId required" });
    // Load existing
    const data = JSON.parse(fs.readFileSync(ENV_PATH, "utf8"));
    data.zones = data.zones || [];
    let zone = data.zones.find(z => z.id === zoneId);
    if (!zone) {
      zone = { id: zoneId, name: name || zoneId, location: name || zoneId, sensors: {} };
      data.zones.push(zone);
    }
    zone.name = name || zone.name;
    zone.location = zone.location || zone.name;
    zone.meta = zone.meta || {};
    if (source) zone.meta.source = source;
    if (typeof battery === "number") zone.meta.battery = battery;
    if (typeof rssi === "number") zone.meta.rssi = rssi;

    const ensure = (k, val, unit) => {
      zone.sensors[k] = zone.sensors[k] || { current: null, setpoint: { min: null, max: null }, history: [] };
      if (typeof val === "number" && !Number.isNaN(val)) {
        zone.sensors[k].current = val;
        zone.sensors[k].history = [val, ...(zone.sensors[k].history || [])].slice(0, 100);
      }
    };
    ensure("tempC", temperature);
    ensure("rh", humidity);
    ensure("vpd", vpd);
    ensure("co2", co2);

    fs.writeFileSync(ENV_PATH, JSON.stringify(data, null, 2));
    return res.json({ ok: true });
  } catch (e) {
    return res.status(500).json({ ok: false, error: e.message });
  }
});

// Generic save endpoint for JSON files in public/data (e.g., groups.json, schedules.json, device-meta.json)
app.post("/data/:name", (req, res) => {
  try {
    const name = req.params.name || "";
    if (!name.endsWith(".json")) return res.status(400).json({ ok: false, error: "Only .json files allowed" });
    const full = path.join(DATA_DIR, path.basename(name));
    fs.writeFileSync(full, JSON.stringify(req.body, null, 2));
    return res.json({ ok: true });
  } catch (e) {
    return res.status(500).json({ ok: false, error: e.message });
  }
});

app.listen(PORT, () => {
  console.log(`[charlie] running http://127.0.0.1:${PORT} → ${CTRL}`);
});
